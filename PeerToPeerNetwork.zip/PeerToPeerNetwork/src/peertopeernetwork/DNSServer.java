package peertopeernetwork;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class DNSServer extends Thread {

    int port = 60500;
    ServerSocket server;
    ArrayList<Integer> dhtServers = new ArrayList<>();
    ArrayList<Integer> cryptServers = new ArrayList<>();

    DNSServer() throws IOException {
        ServerSocket CreateServer = new ServerSocket(port, 60500);
        server = CreateServer;
    }

    public void run() {
        Thread listen = new Listen(server);
        listen.start();
    }

    class Listen extends Thread {

        ServerSocket server;

        Listen(ServerSocket server) {
            this.server = server;
        }

        public void run() {
            while (true) {
                try {

                    Socket serverSocket = server.accept();
                    Thread processRequest = new communicate(serverSocket);
                    processRequest.start();
                } catch (IOException ex) {
                    Logger.getLogger(Listen.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    class communicate extends Thread {

        private Socket socket;

        communicate(Socket socket) {
            this.socket = socket;
        }

        boolean addServers(JSONObject requestJSON) {
            boolean added = true;
            try {
                ArrayList<Integer> temp2 = new ArrayList<>();
                boolean isDHT = !(requestJSON.get("dht") == null);
                JSONArray dhtJOSNArray = (JSONArray) (isDHT ? requestJSON.get("dht") : requestJSON.get("wellknownServers"));
                Iterator<String> iterator = dhtJOSNArray.iterator();
                while (iterator.hasNext()) {
                    ArrayList<Integer> temp = (isDHT ? dhtServers : cryptServers);
                    synchronized (temp) {
                        int port = Integer.parseInt((iterator.next()));
                        temp.add(port);
                        temp2.add(port);
                    }
                }
                if(!isDHT){
                    for(Integer portNumber : temp2){
                        sendListToNode(cryptServers, portNumber);
                    }
                }
            } catch (Exception e) {
                System.err.println(""+e);
                added = false;
            }
            return added;
        }

        String createResponse(String request) {
            String response = "";
            JSONObject requestJSON = parseJSON(request);
            if (((String) requestJSON.get("type")).equals("POST") && requestJSON.get("dht") != null) {
                boolean dhtAdded = addServers(requestJSON);
                JSONObject obj = new JSONObject();
                if (dhtAdded) {
                    obj.put("success", "1");
                } else {
                    obj.put("success", "0");
                }
                response = "[" + obj.toJSONString() + "]";
            } else if (((String) requestJSON.get("type")).equals("GET") && requestJSON.get("dht") != null) {
                int n = dhtServers.size();
                JSONObject obj = new JSONObject();
                if (n == 0) {
                    obj.put("success", "0");
                } else {
                    Random num = new Random();
                    int randomServer = num.nextInt(n);
                    obj.put("success", "1");
                    obj.put("dhtServers", dhtServers.get(randomServer) + "");
                }
                response = "[" + obj.toJSONString() + "]";
            } else if (((String) requestJSON.get("type")).equals("POST") && requestJSON.get("wellknownServers") != null) {
                boolean dhtAdded = addServers(requestJSON);
                JSONObject obj = new JSONObject();
                if (dhtAdded) {
                    obj.put("success", "1");
                } else {
                    obj.put("success", "0");
                }
                response = "[" + obj.toJSONString() + "]";
            } else if (((String) requestJSON.get("type")).equals("GET") && requestJSON.get("wellknownServers") != null) {
                int n = cryptServers.size();
                JSONObject obj = new JSONObject();
                if (n == 0) {
                    obj.put("success", "0");
                } else {
                    Random num = new Random();
                    int randomServer = num.nextInt(n);
                    obj.put("success", "1");
                    obj.put("dhtServers", cryptServers.get(randomServer) + "");
                }
                response = "[" + obj.toJSONString() + "]";
            }
            return response;
        }

        String readRequest(Socket server) throws IOException {
            String request = "";
            InputStream inFromServer = server.getInputStream();
            DataInputStream in = new DataInputStream(inFromServer);
            request = in.readUTF();
            return request;
        }

        void sendResponse(String response, Socket socket) throws IOException {
            OutputStream outToServer = socket.getOutputStream();
            DataOutputStream out = new DataOutputStream(outToServer);
            out.writeUTF(response);
            socket.close();
        }
        
        void sendListToNode(ArrayList<Integer> argList, int argPortNumber) throws IOException {
            //System.err.println(argList+"List sent to port:"+argPortNumber);
            JSONObject message = new JSONObject();
            message.put("type", "LIST");
            message.put("List", argList);
            Socket s = new Socket("localhost", argPortNumber);
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            dout.writeUTF("[" + message.toJSONString() + "]");
            dout.flush();
            dout.close();
            s.close();
        }

        JSONObject parseJSON(String json) {
            JSONObject obj2;
            try {
                JSONParser parser = new JSONParser();
                JSONArray a = (JSONArray) parser.parse(json);
                obj2 = (JSONObject) a.get(0);
            } catch (ParseException ex) {
                obj2 = null;
                Logger.getLogger(DNSServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            return obj2;
        }

        public void run() {
            try {
                String request = readRequest(socket);
                String response = createResponse(request);
                sendResponse(response, socket);
            } catch (IOException ex) {
                Logger.getLogger(DNSServer.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /*public static void main(String args[]) throws ParseException, IOException {
        
    }*/
}